#!/bin/sh
java -jar -XX:MinHeapFreeRatio=5 -XX:MaxHeapFreeRatio=5 $( dirname $( cd `dirname $0` >/dev/null; pwd ) )/${PWD##*/}/GoearD.jar
